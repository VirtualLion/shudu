//
//  ViewController.m
//  YZShuDuDemo
//
//  Created by 韩云智 on 2017/2/20.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "ViewController.h"
#import "UIView+SDAutoLayout.h"

#import "YZViewModel.h"
#import "YZShuDuView.h"

@interface ViewController ()

@property (nonatomic, strong) YZViewModel * viewModel;

@property (nonatomic, assign) BOOL isOkey;

@end

@implementation ViewController

- (void)doTry{
    _isOkey = YES;
    [self chickArr:_viewModel.rowArr];
    [self chickArr:_viewModel.colArr];
    [self chickArr:_viewModel.squArr];
    if (!_isOkey) {
        [self doTry];
    }
}

- (void)chickArr:(NSMutableArray *)array{
    for (NSMutableArray * viewArr in array) {
        for (YZShuDuView * view in viewArr) {
            NSMutableArray * array = [NSMutableArray arrayWithArray:view.data];
            for (YZShuDuView * chickView in viewArr) {
                if (![chickView isEqual:view]) {
                    if (view.data.count == 1) {
                        if ([chickView.data containsObject:view.data.firstObject]) {
                            [chickView.data removeObject:view.data.firstObject];
                            _isOkey = NO;
                            [chickView chick];
                        }
                    }else{
                        if (array.count > 0) {
                            NSArray * arr = [NSArray arrayWithArray:array];
                            for (NSString * str in arr) {
                                if ([chickView.data containsObject:str]) {
                                    [array removeObject:str];
                                }
                            }
                        }
                    }
                }
            }
            if (array.count == 1) {
                if (view.data.count > 1) {
                    [view.data removeAllObjects];
                    [view.data addObject:array.firstObject];
                    _isOkey = NO;
                    [view chick];
                }
            }
        }
    }
}

- (void)save{
    for (NSArray * viewArr in _viewModel.rowArr) {
        for (YZShuDuView * view in viewArr) {
            [view save];
        }
    }
}
- (void)undo{
    for (NSArray * viewArr in _viewModel.rowArr) {
        for (YZShuDuView * view in viewArr) {
            [view undo];
        }
    }
}
- (void)reset{
    for (NSArray * viewArr in _viewModel.rowArr) {
        for (YZShuDuView * view in viewArr) {
            [view reset];
        }
    }
}

- (void)toDefault{
    [self reset];
//    NSDictionary * dic = @{
//                           @"11":@"5",
//                           @"15":@"9",
//                           @"17":@"2",
//                           @"19":@"1",
//                           
//                           @"23":@"2",
//                           @"26":@"7",
//                           @"29":@"8",
//                           
//                           @"32":@"8",
//                           @"37":@"3",
//                           
//                           @"42":@"1",
//                           @"43":@"4",
//                           @"46":@"5",
//                           
//                           @"54":@"9",
//                           @"56":@"3",
//                           
//                           @"64":@"8",
//                           @"67":@"9",
//                           @"68":@"4",
//                           
//                           @"73":@"3",
//                           @"78":@"6",
//                           
//                           @"81":@"6",
//                           @"84":@"2",
//                           @"87":@"1",
//                           
//                           @"91":@"8",
//                           @"93":@"9",
//                           @"95":@"6",
//                           @"99":@"5"
//                           };
    
    NSDictionary * dic = @{
                           @"13":@"7",
                           @"14":@"2",
                           @"15":@"3",
                           @"16":@"8",
                           
                           @"22":@"6",
                           @"24":@"7",
                           @"28":@"5",
                           
                           @"34":@"4",
                           @"39":@"2",
                           
                           @"41":@"9",
                           @"47":@"8",
                           @"48":@"6",
                           @"49":@"7",
                           
                           @"51":@"1",
                           @"59":@"3",
                           
                           @"61":@"6",
                           @"62":@"4",
                           @"63":@"8",
                           @"69":@"5",
                           
                           @"71":@"7",
                           @"76":@"3",
                           
                           @"82":@"2",
                           @"86":@"5",
                           @"88":@"3",
                           
                           @"94":@"1",
                           @"95":@"7",
                           @"96":@"4",
                           @"97":@"9"
                           };
    
    for (NSString * str in dic.allKeys) {
        [self toDefaultItem:str.integerValue text:dic[str]];
    }
    
    [self save];
}
- (void)toDefaultItem:(NSInteger)item text:(NSString *)text{
    YZShuDuView * view = _viewModel.rowArr[item/10-1][item%10-1];
    [view toDefault:text];
}

- (void)onBtn:(UIButton *)sender{
    
    switch (sender.tag) {
        case 100:
            [self doTry];
            [self save];
            break;
        case 101:
            [self reset];
            break;
        case 102:
            [self toDefault];
            break;
        case 103:
            [self undo];
            break;
        default:
            break;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self upView];
}

- (void)upView{
    self.view.backgroundColor = [UIColor whiteColor];
    
    _viewModel = [YZViewModel new];
    
    UIButton * btn = [UIButton new];
    [btn setTitle:@"开始" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn.tag = 100;
    [btn addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * btn2 = [UIButton new];
    [btn2 setTitle:@"重置" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn2.tag = 101;
    [btn2 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * btn3 = [UIButton new];
    [btn3 setTitle:@"默认" forState:UIControlStateNormal];
    [btn3 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn3.tag = 102;
    [btn3 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * btn4 = [UIButton new];
    [btn4 setTitle:@"撤销" forState:UIControlStateNormal];
    [btn4 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    btn4.tag = 103;
    [btn4 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view sd_addSubviews:@[btn, btn2, btn3, btn4]];
    [self.view setSd_equalWidthSubviews:@[btn, btn2]];
    
    
    
    btn2.sd_layout
    .bottomEqualToView(self.view)
    .leftEqualToView(self.view)
//    .rightEqualToView(self.view)
    .autoHeightRatio(0.4);
    
    btn.sd_layout
    .bottomEqualToView(self.view)
//    .leftEqualToView(self.view)
    .rightEqualToView(self.view)
    .autoHeightRatio(0.4);
    
    btn3.sd_layout
    .bottomSpaceToView(btn, 0)
    .heightRatioToView(btn, 1)
    .widthRatioToView(btn,1)
    .leftEqualToView(btn);
    
    btn4.sd_layout
    .bottomSpaceToView(btn2, 0)
    .heightRatioToView(btn2, 1)
    .widthRatioToView(btn2,1)
    .leftEqualToView(btn2);
    
    
    
    NSMutableArray * array = [NSMutableArray new];
    double width = ([UIScreen mainScreen].bounds.size.width - 50)/9.;
    for (int j = 0; j < 9; j++) {
        NSMutableArray * labelArr = [NSMutableArray new];
        for (int i = 0; i < 9; i++) {
            YZShuDuView * label = [YZShuDuView new];
            label.backgroundColor = [UIColor yellowColor];
            [label save];
            __weak typeof(self)weakSelf = self;
            label.block = ^(){
                [weakSelf save];
            };
            [self.view sd_addSubviews:@[label]];
            switch (i) {
                case 0:{
                    label.sd_layout
                    .topSpaceToView(j?[array.lastObject lastObject]:self.view, j?(j%3?5:10):20)
                    .leftEqualToView(self.view)
                    .widthIs(width)
                    .autoHeightRatio(1);
                }break;
                case 8:{
                    label.sd_layout
                    .topSpaceToView(j?[array.lastObject lastObject]:self.view, j?(j%3?5:10):20)
                    .leftSpaceToView(labelArr.lastObject, 5)
                    .rightEqualToView(self.view)
                    .widthIs(width)
                    .autoHeightRatio(1);
                }break;
                default:{
                    label.sd_layout
                    .topSpaceToView(j?[array.lastObject lastObject]:self.view, j?(j%3?5:10):20)
                    .leftSpaceToView(labelArr.lastObject, i%3?5:10)
                    .widthIs(width)
                    .autoHeightRatio(1);
                }break;
            }
            [_viewModel.rowArr[j] insertObject:label atIndex:i];
            [_viewModel.colArr[i] insertObject:label atIndex:j];
            [_viewModel.squArr[j/3*3+i/3] addObject:label];
            [labelArr addObject:label];
        }
        [array addObject:labelArr];
    }
    
}

@end
