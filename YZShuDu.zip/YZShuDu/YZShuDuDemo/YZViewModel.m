//
//  YZViewModel.m
//  YZShuDuDemo
//
//  Created by 韩云智 on 2017/2/24.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "YZViewModel.h"

@implementation YZViewModel

- (NSMutableArray *)rowArr{
    if (!_rowArr) {
        _rowArr = [NSMutableArray new];
        for (NSInteger i = 0; i < 9; i++) {
            [_rowArr addObject:[NSMutableArray new]];
        }
    }
    return _rowArr;
}
- (NSMutableArray *)colArr{
    if (!_colArr) {
        _colArr = [NSMutableArray new];
        for (NSInteger i = 0; i < 9; i++) {
            [_colArr addObject:[NSMutableArray new]];
        }
    }
    return _colArr;
}
- (NSMutableArray *)squArr{
    if (!_squArr) {
        _squArr = [NSMutableArray new];
        for (NSInteger i = 0; i < 9; i++) {
            [_squArr addObject:[NSMutableArray new]];
        }
    }
    return _squArr;
}


@end
