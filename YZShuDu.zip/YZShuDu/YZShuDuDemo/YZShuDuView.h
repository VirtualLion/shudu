//
//  YZShuDuView.h
//  YZShuDuDemo
//
//  Created by 韩云智 on 2017/3/9.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZShuDuView : UIView

@property (nonatomic, copy) void (^block)();
@property (nonatomic, strong) NSMutableArray * data;

- (void)chick;
- (void)reset;
- (void)save;
- (void)undo;
- (void)toDefault:(NSString *)text;
@end
