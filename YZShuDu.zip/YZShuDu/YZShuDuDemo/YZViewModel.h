//
//  YZViewModel.h
//  YZShuDuDemo
//
//  Created by 韩云智 on 2017/2/24.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YZViewModel : NSObject

@property (nonatomic, strong) NSMutableArray * rowArr;
@property (nonatomic, strong) NSMutableArray * colArr;
@property (nonatomic, strong) NSMutableArray * squArr;

@end
