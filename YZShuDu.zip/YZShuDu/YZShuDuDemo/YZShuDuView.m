//
//  YZShuDuView.m
//  YZShuDuDemo
//
//  Created by 韩云智 on 2017/3/9.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "YZShuDuView.h"
#import "UIView+SDAutoLayout.h"

@interface YZShuDuView ()<UITextFieldDelegate>

@property (nonatomic, strong) UITextField * textField;

@property (nonatomic, strong) NSMutableArray * saveArr;

@end

@implementation YZShuDuView

- (void)chick{
//    if (_textField.text.length > 0) {
//        return;
//    }
    if (self.data.count ==1) {
        _textField.text = self.data.firstObject;
    }else{
        NSString * str = [self.data componentsJoinedByString:@""];
        _textField.text = str;
    }
}

- (void)reset{
    _textField.text = @"";
    self.backgroundColor = [UIColor yellowColor];
    _data = nil;
}

- (void)save{
    NSDictionary * dic = @{@"color":self.backgroundColor,
                           @"data":[NSArray arrayWithArray:self.data],
                           @"text":[NSString stringWithFormat:@"%@",_textField.text]};
    [_saveArr addObject:dic];
}

- (void)undo{
    if (_saveArr.count > 1) {
        [_saveArr removeLastObject];
        NSDictionary * dic = _saveArr.lastObject;
        self.backgroundColor = dic[@"color"];
        _textField.text = dic[@"text"];
        [self.data removeAllObjects];
        [self.data addObjectsFromArray:dic[@"data"]];
    }
}

- (void)toDefault:(NSString *)text{
    _textField.text = text;
    self.backgroundColor = [UIColor lightGrayColor];
    [self.data removeAllObjects];
    [self.data addObject:text];
}

- (NSMutableArray *)data{
    if (!_data) {
        _data = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9", nil];
    }
    return _data;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self upView];
    }
    return self;
}

- (void)upView{
    _saveArr = [NSMutableArray new];
    _textField = [UITextField new];
    _textField.keyboardType = UIKeyboardTypeNumberPad;
    _textField.textAlignment = NSTextAlignmentCenter;
    _textField.adjustsFontSizeToFitWidth = YES;
    _textField.minimumFontSize = 0.1;
    _textField.delegate = self;
    [self sd_addSubviews:@[_textField]];
    _textField.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (string.length>0) {
        self.backgroundColor = [UIColor lightGrayColor];
        [self.data removeAllObjects];
        [self.data addObject:string];
    }else{
        self.backgroundColor = [UIColor yellowColor];
        _data = nil;
    }
    textField.text = string;
    if (_block) {
        _block();
    }
    [textField resignFirstResponder];
    
    return YES;
}

@end
